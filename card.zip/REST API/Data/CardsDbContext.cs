﻿using REST_API.Models;
using Microsoft.EntityFrameworkCore;


namespace REST_API.Data
{
    public class CardsDbContext : DbContext
    {
        public CardsDbContext(DbContextOptions options) : base(options)
        {
        }

        //Dbset
        public DbSet<Cards> Cards { get; set; }
    }
}
