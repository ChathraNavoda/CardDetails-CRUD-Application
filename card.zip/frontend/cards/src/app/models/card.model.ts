export interface Card{
    id: string;
    cardHolderName: string;
    cardNumber: string;
    cvc: string;
    expiryMonth: string;
    expiryYear: string;
}